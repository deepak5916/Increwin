﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    public class FlightBooking
    {
        public void BookFLight(string CustomerNAme , string AirlineName , string source , string destination , DateTime Date)
        {
            // Insert Details into DB

        }
    }
}
