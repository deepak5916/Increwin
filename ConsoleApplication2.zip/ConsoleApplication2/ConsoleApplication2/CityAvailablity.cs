﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    public class CityAvailablity
    {

        public bool FlightsAvailableBetweenCities(string sourceCity , string DestinationCity , DateTime date)
        {
            return true; // logic needs to implement
        }
    }
}
