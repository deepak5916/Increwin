﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    public class AddUpdateHotelFlight
    {

        public void RoomAvailablinility(string hotelName, int availableRooms)
        {
        }

        public void SeatsAvailale(string FlightNo, int availableSeats)
        {

        }
    }
}
