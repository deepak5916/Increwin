﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    public class TravelAgentCreateFlight
    {
        public void CreateNewFlight(string source, string destination, int availableSeats)
        {
            // Insert Flight into DB
        }
    }
}
