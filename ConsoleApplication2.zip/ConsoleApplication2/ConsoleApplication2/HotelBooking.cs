﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    public class HotelAndFlightBooking
    {
        public void InsertHotelAndFlight(string hotelName , int roomNumber, string cityName)
        {
            // logic to insert data into DB

            FlightBooking fb = new FlightBooking();
            fb.BookFLight("Deep", "Indigo", "LKO", "BLR", DateTime.Now);
            HotelAndFlightBooking.BookHotel(1, "BLR", "OYO");
            
        }

        private static void BookHotel(int roomNumber, string city, string HotelName)
        {
            // logic to create Hotel Booking
        }
    }
}
