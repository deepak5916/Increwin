﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    public class TravelAgentAddHotel
    {
        public void AddNewHotel(string city, int roomsAvailable)
        {
            // Insert new Hotel into DB
        }
    }
}
